
import React from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button.jsx';
import { MessageCircle, UtensilsCrossed, MapPin, Clock } from 'lucide-react';
import { useEditableContent } from '@/contexts/EditableContent.jsx';
import { motion } from 'framer-motion';
import MenuSection from '@/components/MenuSection.jsx';
import WeekendSpecialsSection from '@/components/WeekendSpecialsSection.jsx';
import GallerySection from '@/components/GallerySection.jsx';
import ContactSection from '@/components/ContactSection.jsx';

const HomePage = () => {
  const { data } = useEditableContent();

  const scrollToMenu = () => {
    const element = document.getElementById('menu');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent('Hola! Me gustaría hacer un pedido');
    window.open(`https://wa.me/${data.businessInfo.whatsapp.replace(/\D/g, '')}?text=${message}`, '_blank');
  };

  return (
    <>
      <Helmet>
        <title>{`MARIA BONITA - ${data.businessInfo.subtitle}`}</title>
        <meta 
          name="description" 
          content={`${data.businessInfo.tagline}. Disfruta de los mejores tacos y antojitos mexicanos en ${data.businessInfo.address}`}
        />
      </Helmet>

      {/* Hero Section - Rustic Mexican Redesign */}
      <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background border-b-[12px] border-border">
        {/* Background Image */}
        <div 
          className="absolute inset-0 z-0 bg-[url('https://images.unsplash.com/photo-1583438899925-84fde80483b9?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center bg-no-repeat"
        ></div>
        
        {/* Overlays */}
        <div className="absolute inset-0 z-0 bg-background/80 mix-blend-multiply"></div>
        <div className="absolute inset-0 z-0 wood-pattern-dark opacity-70"></div>
        <div className="absolute inset-0 z-0 bg-gradient-to-b from-black/80 via-black/40 to-background"></div>

        {/* Decorative Food Images (Absolute positioned) */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.5, delay: 0.5 }}
          className="absolute top-20 left-10 w-64 h-64 rounded-full overflow-hidden border-8 border-muted shadow-rustic hidden lg:block opacity-80 mix-blend-luminosity"
        >
          <img src="https://images.unsplash.com/photo-1613591629098-8eb619ef84dd?q=80&w=600&auto=format&fit=crop" alt="Tacos" className="w-full h-full object-cover" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.5, delay: 0.7 }}
          className="absolute bottom-20 right-10 w-80 h-80 rounded-full overflow-hidden border-8 border-muted shadow-rustic hidden lg:block opacity-80 mix-blend-luminosity"
        >
          <img src="https://images.unsplash.com/photo-1697410154169-b2bbf83758e6?q=80&w=600&auto=format&fit=crop" alt="Clay pots" className="w-full h-full object-cover" />
        </motion.div>

        {/* Main Content Container */}
        <div className="relative z-10 container mx-auto px-4 py-20 flex flex-col items-center justify-center min-h-screen">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="w-full max-w-5xl relative"
          >
            {/* Rustic Frame */}
            <div className="absolute inset-0 border-[20px] border-border rounded-sm opacity-90 mix-blend-overlay pointer-events-none shadow-[inset_0_0_60px_rgba(0,0,0,0.9)]"></div>
            <div className="absolute inset-4 border-4 border-double border-muted rounded-sm pointer-events-none z-20 opacity-80"></div>
            
            {/* Poster Background */}
            <div className="bg-background/60 backdrop-blur-md p-8 md:p-16 border-8 border-muted rounded-sm shadow-rustic relative overflow-hidden">
              
              {/* Corner Decorations */}
              <div className="absolute top-6 left-6 w-12 h-12 border-t-4 border-l-4 border-secondary"></div>
              <div className="absolute top-6 right-6 w-12 h-12 border-t-4 border-r-4 border-secondary"></div>
              <div className="absolute bottom-6 left-6 w-12 h-12 border-b-4 border-l-4 border-secondary"></div>
              <div className="absolute bottom-6 right-6 w-12 h-12 border-b-4 border-r-4 border-secondary"></div>

              <div className="flex flex-col items-center text-center relative z-20">
                
                {/* Top Branding */}
                <motion.div 
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 0.8 }}
                  className="flex items-center justify-center space-x-6 mb-10 w-full"
                >
                  <div className="h-1 flex-1 bg-gradient-to-r from-transparent via-secondary to-transparent"></div>
                  <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground tracking-[0.4em] uppercase drop-shadow-md">
                    MARIA BONITA
                  </h2>
                  <div className="h-1 flex-1 bg-gradient-to-r from-transparent via-secondary to-transparent"></div>
                </motion.div>

                {/* Main Heading */}
                <div className="space-y-8 mb-12 w-full">
                  <motion.h1 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.7, duration: 0.8 }}
                    className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-foreground leading-tight tracking-wide drop-shadow-lg uppercase"
                  >
                    SI CAES QUE SEA EN LA TENTACIÓN
                  </motion.h1>

                  {/* Mexican Pink Banner */}
                  <motion.div 
                    initial={{ x: -50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.9, duration: 0.6, type: "spring" }}
                    className="relative inline-block w-full max-w-3xl mx-auto my-6"
                  >
                    <div className="absolute inset-0 bg-primary transform -skew-x-6 shadow-rustic border-4 border-border"></div>
                    <h2 className="relative z-10 text-6xl md:text-8xl font-rustic text-white px-10 py-6 block tracking-widest uppercase drop-shadow-md">
                      DE UNOS
                    </h2>
                  </motion.div>

                  <motion.h1 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 1.1, duration: 0.8 }}
                    className="text-8xl md:text-9xl lg:text-[10rem] font-serif font-bold text-secondary tracking-widest drop-shadow-xl mt-6 uppercase"
                  >
                    TACOS
                  </motion.h1>
                </div>

                {/* Decorative Divider */}
                <div className="flex justify-center items-center mb-12 space-x-4">
                  <div className="h-2 w-32 bg-muted"></div>
                  <div className="w-6 h-6 bg-primary rotate-45 border-2 border-border"></div>
                  <div className="w-8 h-8 bg-secondary rotate-45 border-2 border-border"></div>
                  <div className="w-6 h-6 bg-primary rotate-45 border-2 border-border"></div>
                  <div className="h-2 w-32 bg-muted"></div>
                </div>

                {/* Action Buttons */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.5, duration: 0.8 }}
                  className="flex flex-col sm:flex-row items-center justify-center gap-8 w-full max-w-2xl mt-4"
                >
                  <Button
                    onClick={scrollToMenu}
                    size="lg"
                    className="w-full sm:w-auto text-2xl px-12 py-10 bg-card hover:bg-card/90 text-card-foreground border-8 border-muted shadow-rustic transition-all hover:-translate-y-1 rounded-sm font-serif font-bold uppercase tracking-wider"
                  >
                    <UtensilsCrossed className="w-8 h-8 mr-4 text-secondary" />
                    Ver Menú
                  </Button>
                  <Button
                    onClick={handleWhatsAppClick}
                    size="lg"
                    className="w-full sm:w-auto text-2xl px-12 py-10 bg-primary hover:bg-primary/90 text-white border-8 border-border shadow-rustic transition-all hover:-translate-y-1 rounded-sm font-serif font-bold uppercase tracking-wider"
                  >
                    <MessageCircle className="w-8 h-8 mr-4" />
                    Pedir Ahora
                  </Button>
                </motion.div>

              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-card parchment-pattern border-b-[12px] border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center bg-white/60 p-12 rounded-sm border-4 border-muted shadow-rustic relative">
            {/* Decorative corner */}
            <div className="absolute top-0 left-0 w-16 h-16 bg-secondary transform -translate-x-8 -translate-y-8 rotate-45"></div>
            
            <h2 className="text-5xl md:text-6xl font-serif font-bold text-card-foreground mb-8 uppercase tracking-wider">Nuestra Historia</h2>
            <div className="flex justify-center items-center space-x-4 mb-8">
              <div className="h-1 w-16 bg-secondary"></div>
              <div className="w-4 h-4 bg-primary rotate-45"></div>
              <div className="h-1 w-16 bg-secondary"></div>
            </div>
            <p className="text-2xl font-serif text-card-foreground/90 leading-relaxed mb-10 font-medium">
              En MARIA BONITA, preparamos cada platillo con la misma pasión y sazón que nos enseñaron en casa. 
              Utilizamos ingredientes frescos, tortillas hechas a mano y salsas de molcajete para llevar 
              el verdadero sabor de México a tu mesa.
            </p>
            <div className="flex justify-center gap-6">
              <div className="w-20 h-20 bg-primary rounded-full border-4 border-border shadow-md flex items-center justify-center">
                <span className="font-rustic text-white text-2xl">100%</span>
              </div>
              <div className="w-20 h-20 bg-secondary rounded-full border-4 border-border shadow-md flex items-center justify-center">
                <span className="font-rustic text-white text-xl text-center leading-none">SABOR<br/>REAL</span>
              </div>
              <div className="w-20 h-20 bg-accent rounded-full border-4 border-border shadow-md flex items-center justify-center">
                <span className="font-rustic text-white text-xl text-center leading-none">HECHO<br/>A MANO</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <MenuSection />
      <WeekendSpecialsSection />
      <GallerySection />
      <ContactSection />
    </>
  );
};

export default HomePage;
