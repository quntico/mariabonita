
import React, { createContext, useContext, useState, useEffect } from 'react';

const EditableContentContext = createContext();

const initialData = {
  businessInfo: {
    name: "LA FÉLIX",
    subtitle: "Tacos & Antojitos Mexicanos",
    tagline: "Auténtico sabor mexicano con tradición y corazón",
    whatsapp: "+521234567890",
    phone: "+521234567890",
    email: "contacto@lafelix.com",
    address: "Calle Principal #123, Colonia Centro, Ciudad de México",
    hours: {
      weekdays: "Lunes a Viernes: 8:00 AM - 10:00 PM",
      weekends: "Sábados y Domingos: 8:00 AM - 11:00 PM"
    },
    social: {
      facebook: "https://facebook.com/lafelix",
      instagram: "https://instagram.com/lafelix",
      twitter: "https://twitter.com/lafelix"
    },
    heroImage: "https://images.unsplash.com/photo-1701407312283-48083fa2c94d"
  },
  posterConfig: {
    titlePart1: "SI CAES QUE SEA EN LA TENTACIÓN",
    bannerText: "DE UNOS",
    titlePart2: "TACOS",
    footerText: "¡GRACIAS POR SU PREFERENCIA!"
  },
  menu: {
    tacos: [
      { id: 1, name: "Cecina", description: "", price: 15, recommended: true },
      { id: 2, name: "Bistec", description: "", price: 15, recommended: false },
      { id: 3, name: "Longaniza roja", description: "", price: 15, recommended: false },
      { id: 4, name: "Chorizo verde", description: "", price: 15, recommended: true },
      { id: 5, name: "Pechuga", description: "", price: 15, recommended: false },
      { id: 6, name: "Campechanos", description: "", price: 18, recommended: true }
    ],
    desayunos: [
      { id: 7, name: "Chilaquiles verdes", description: "", price: 45, recommended: true },
      { id: 8, name: "Chilaquiles rojos", description: "", price: 45, recommended: false },
      { id: 9, name: "Huevos al gusto", description: "", price: 40, recommended: false },
      { id: 10, name: "Molletes dulces", description: "", price: 35, recommended: false },
      { id: 11, name: "Molletes salados", description: "", price: 35, recommended: false },
      { id: 12, name: "Waffles", description: "", price: 40, recommended: true }
    ],
    otros: [
      { id: 13, name: "Comida corrida", description: "", price: 65, recommended: true }
    ],
    quesadillas: [
      { id: 14, name: "Quesadillas", description: "", price: 25, recommended: false },
      { id: 15, name: "Sincronizadas", description: "", price: 30, recommended: false }
    ],
    weekendSpecials: [
      { id: 16, name: "Barbacoa", description: "", price: 120, recommended: true },
      { id: 17, name: "Pozole", description: "", price: 80, recommended: true },
      { id: 18, name: "Pancita", description: "", price: 70, recommended: false }
    ],
    bebidas: [
      { id: 19, name: "Aguas frescas", description: "", price: 20, recommended: false },
      { id: 20, name: "Refrescos", description: "", price: 18, recommended: false },
      { id: 21, name: "Licuados", description: "", price: 30, recommended: true },
      { id: 22, name: "Café", description: "", price: 25, recommended: false }
    ]
  },
  gallery: [
    { id: 1, url: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47", title: "Tacos al Pastor" },
    { id: 2, url: "https://images.unsplash.com/photo-1613514785940-daed07799d9b", title: "Tacos Dorados" },
    { id: 3, url: "https://images.unsplash.com/photo-1599974579688-8dbdd335c77f", title: "Quesadillas" }
  ],
  weekendSpecialsActive: true
};

export const EditableContentProvider = ({ children }) => {
  const [data, setData] = useState(() => {
    const saved = localStorage.getItem('lafelixData_v3');
    return saved ? JSON.parse(saved) : initialData;
  });
  
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    localStorage.setItem('lafelixData_v3', JSON.stringify(data));
  }, [data]);

  const updateBusinessInfo = (field, value) => {
    setData(prev => ({
      ...prev,
      businessInfo: {
        ...prev.businessInfo,
        [field]: value
      }
    }));
  };

  const updatePosterConfig = (field, value) => {
    setData(prev => ({
      ...prev,
      posterConfig: {
        ...prev.posterConfig,
        [field]: value
      }
    }));
  };

  const updateHours = (type, value) => {
    setData(prev => ({
      ...prev,
      businessInfo: {
        ...prev.businessInfo,
        hours: {
          ...prev.businessInfo.hours,
          [type]: value
        }
      }
    }));
  };

  const updateSocial = (platform, value) => {
    setData(prev => ({
      ...prev,
      businessInfo: {
        ...prev.businessInfo,
        social: {
          ...prev.businessInfo.social,
          [platform]: value
        }
      }
    }));
  };

  const updateMenuItem = (category, itemId, field, value) => {
    setData(prev => ({
      ...prev,
      menu: {
        ...prev.menu,
        [category]: prev.menu[category].map(item =>
          item.id === itemId ? { ...item, [field]: value } : item
        )
      }
    }));
  };

  const addMenuItem = (category, item) => {
    setData(prev => ({
      ...prev,
      menu: {
        ...prev.menu,
        [category]: [...prev.menu[category], { ...item, id: Date.now() }]
      }
    }));
  };

  const removeMenuItem = (category, itemId) => {
    setData(prev => ({
      ...prev,
      menu: {
        ...prev.menu,
        [category]: prev.menu[category].filter(item => item.id !== itemId)
      }
    }));
  };

  const addGalleryImage = (image) => {
    setData(prev => ({
      ...prev,
      gallery: [...prev.gallery, { ...image, id: Date.now() }]
    }));
  };

  const updateGalleryImage = (imageId, field, value) => {
    setData(prev => ({
      ...prev,
      gallery: prev.gallery.map(img =>
        img.id === imageId ? { ...img, [field]: value } : img
      )
    }));
  };

  const removeGalleryImage = (imageId) => {
    setData(prev => ({
      ...prev,
      gallery: prev.gallery.filter(img => img.id !== imageId)
    }));
  };

  const toggleWeekendSpecials = () => {
    setData(prev => ({
      ...prev,
      weekendSpecialsActive: !prev.weekendSpecialsActive
    }));
  };

  const value = {
    data,
    editMode,
    setEditMode,
    updateBusinessInfo,
    updatePosterConfig,
    updateHours,
    updateSocial,
    updateMenuItem,
    addMenuItem,
    removeMenuItem,
    addGalleryImage,
    updateGalleryImage,
    removeGalleryImage,
    toggleWeekendSpecials
  };

  return (
    <EditableContentContext.Provider value={value}>
      {children}
    </EditableContentContext.Provider>
  );
};

export const useEditableContent = () => {
  const context = useContext(EditableContentContext);
  if (!context) {
    throw new Error('useEditableContent must be used within EditableContentProvider');
  }
  return context;
};
