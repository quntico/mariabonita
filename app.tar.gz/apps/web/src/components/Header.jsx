
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Save, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { useEditableContent } from '@/contexts/EditableContent.jsx';
import { motion, AnimatePresence } from 'framer-motion';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { editMode, setEditMode } = useEditableContent();

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-[#1a1a1a] text-white border-b border-secondary/30 shadow-gold">
      {/* Elegant Golden Top Accent */}
      <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-secondary to-transparent z-10 opacity-70"></div>
      
      <div className="container mx-auto px-4 relative z-20">
        <div className="flex items-center justify-between h-28">
          {/* Logo - Option 2 Aesthetic (Compact & Warm) */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="flex flex-col items-center justify-center border border-secondary/50 px-3 py-1.5 bg-[#8B5A3C] group-hover:border-secondary transition-all duration-500 relative overflow-hidden shadow-lg">
              {/* Golden Corner Flourishes */}
              <div className="absolute top-0.5 left-0.5 w-1.5 h-1.5 border-t border-l border-secondary opacity-70"></div>
              <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 border-t border-r border-secondary opacity-70"></div>
              <div className="absolute bottom-0.5 left-0.5 w-1.5 h-1.5 border-b border-l border-secondary opacity-70"></div>
              <div className="absolute bottom-0.5 right-0.5 w-1.5 h-1.5 border-b border-r border-secondary opacity-70"></div>

              <span className="text-2xl md:text-3xl font-serif font-bold text-white tracking-[0.15em] uppercase z-10 drop-shadow-md ml-[0.15em]">
                MARIA BONITA
              </span>
              
              {/* Mexican Pink & Gold Accent Line */}
              <div className="flex items-center space-x-2 mt-0.5 z-10">
                <div className="h-[1px] w-8 bg-secondary/70"></div>
                <div className="h-1.5 w-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(255,63,152,0.6)]"></div>
                <div className="h-[1px] w-8 bg-secondary/70"></div>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-10">
            {['Inicio', 'Menú', 'Nosotros', 'Contacto'].map((item, idx) => (
              <button
                key={idx}
                onClick={() => scrollToSection(item === 'Nosotros' ? 'about' : item.toLowerCase())}
                className="text-sm md:text-base font-serif font-bold text-white/90 hover:text-secondary py-2 relative group uppercase tracking-widest transition-colors duration-300"
              >
                {item}
                {/* Golden underline effect */}
                <span className="absolute bottom-0 left-1/2 w-0 h-[2px] bg-secondary transform -translate-x-1/2 group-hover:w-full transition-all duration-300 ease-out"></span>
              </button>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center space-x-6">
            {/* Vertical Golden Divider */}
            <div className="hidden md:block w-[1px] h-8 bg-secondary/30"></div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setEditMode(!editMode)}
              className={`hidden sm:flex items-center space-x-2 border ${editMode ? 'bg-primary text-white border-primary hover:bg-primary/90 shadow-[0_0_15px_rgba(255,63,152,0.4)]' : 'bg-transparent text-secondary border-secondary/50 hover:bg-secondary/10 hover:border-secondary transition-all duration-300'}`}
            >
              {editMode ? <Save className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
              <span className="font-serif font-bold tracking-wider uppercase text-xs">{editMode ? 'Guardar' : 'Admin'}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="md:hidden text-secondary hover:bg-secondary/10 border border-secondary/30 bg-transparent"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#1a1a1a] border-t border-secondary/30 relative z-10 shadow-xl"
          >
            <nav className="container mx-auto px-4 py-8 flex flex-col space-y-6">
              {['Inicio', 'Menú', 'Nosotros', 'Contacto'].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => scrollToSection(item === 'Nosotros' ? 'about' : item.toLowerCase())}
                  className="text-center py-3 px-6 text-xl font-serif font-bold text-white/90 border border-secondary/20 rounded-sm hover:border-secondary hover:text-secondary transition-all uppercase tracking-widest"
                >
                  {item}
                </button>
              ))}
              <div className="pt-6 border-t border-secondary/20 flex justify-center">
                <Button
                  variant={editMode ? "default" : "outline"}
                  onClick={() => {
                    setEditMode(!editMode);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full max-w-xs flex items-center justify-center space-x-3 border h-14 ${editMode ? 'bg-primary text-white border-primary shadow-[0_0_15px_rgba(255,63,152,0.4)]' : 'bg-transparent text-secondary border-secondary/50 hover:bg-secondary/10'}`}
                >
                  {editMode ? <Save className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                  <span className="font-serif font-bold text-lg tracking-widest uppercase">{editMode ? 'Guardar Cambios' : 'Admin Login'}</span>
                </Button>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
