
import React, { useRef, useState } from 'react';
import { useEditableContent } from '@/contexts/EditableContent';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Download, FileText, Plus, Trash2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { useToast } from '@/hooks/use-toast';

const InlineEdit = ({ value, onChange, isEditing, className, type = "text" }) => {
  if (isEditing) {
    return (
      <Input
        type={type}
        value={value}
        onChange={(e) => onChange(type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value)}
        className={`h-8 bg-white/50 border-border/30 text-card-foreground placeholder:text-card-foreground/50 ${className}`}
      />
    );
  }
  return <span className={className}>{value}</span>;
};

const MenuPoster = () => {
  const { data, editMode, updateMenuItem, updatePosterConfig, addMenuItem, removeMenuItem } = useEditableContent();
  const posterRef = useRef(null);
  const { toast } = useToast();
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadPNG = async () => {
    if (!posterRef.current) return;
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(posterRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#e8dcc8'
      });
      const link = document.createElement('a');
      link.download = 'menu-maria-bonita.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
      toast({ title: "¡Éxito!", description: "Menú descargado como PNG" });
    } catch (error) {
      toast({ title: "Error", description: "No se pudo descargar la imagen", variant: "destructive" });
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!posterRef.current) return;
    setIsDownloading(true);
    try {
      const canvas = await html2canvas(posterRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#e8dcc8'
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', [215.9, 355.6]); // 8.5x14 inches in mm
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('menu-maria-bonita.pdf');
      toast({ title: "¡Éxito!", description: "Menú descargado como PDF" });
    } catch (error) {
      toast({ title: "Error", description: "No se pudo descargar el PDF", variant: "destructive" });
    } finally {
      setIsDownloading(false);
    }
  };

  const renderMenuItem = (item, category) => (
    <div key={item.id} className="flex justify-between items-end mb-4 group relative pl-6 border-b-2 border-muted/30 pb-2">
      {/* Decorative Bullet Point */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-secondary rotate-45"></div>
      
      <div className="flex-1 mr-4">
        <InlineEdit
          value={item.name}
          onChange={(val) => updateMenuItem(category, item.id, 'name', val)}
          isEditing={editMode}
          className="text-xl md:text-2xl font-serif font-bold text-card-foreground tracking-wide uppercase"
        />
      </div>
      <div className="flex items-center">
        <span className="text-xl md:text-2xl font-bold text-primary mr-1">$</span>
        <InlineEdit
          value={item.price}
          onChange={(val) => updateMenuItem(category, item.id, 'price', val)}
          isEditing={editMode}
          type="number"
          className="text-xl md:text-2xl font-bold text-card-foreground w-16 text-right"
        />
        {editMode && (
          <button 
            onClick={() => removeMenuItem(category, item.id)}
            className="ml-2 text-destructive hover:text-destructive/80 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto">
      {/* Poster Container - Aspect Ratio 8.5x14 */}
      <div 
        ref={posterRef}
        className="w-full bg-card text-card-foreground p-8 md:p-12 relative overflow-hidden shadow-rustic parchment-pattern flex flex-col border-8 border-border"
        style={{ minHeight: '1200px' }}
      >
        {/* Inner Decorative Frame */}
        <div className="absolute inset-4 border-4 border-double border-muted rounded-sm pointer-events-none z-20 opacity-80"></div>
        <div className="absolute inset-8 border border-secondary/50 rounded-sm pointer-events-none z-20"></div>

        {/* Header Section */}
        <div className="text-center mb-12 relative z-30 pt-8">
          <InlineEdit
            value={data.posterConfig.titlePart1}
            onChange={(val) => updatePosterConfig('titlePart1', val)}
            isEditing={editMode}
            className="text-3xl md:text-5xl font-serif font-bold text-secondary block mb-4 tracking-widest uppercase"
          />
          
          <div className="relative inline-block my-6 w-full max-w-2xl">
            <div className="absolute inset-0 bg-primary transform -skew-x-6 shadow-md"></div>
            <InlineEdit
              value={data.posterConfig.bannerText}
              onChange={(val) => updatePosterConfig('bannerText', val)}
              isEditing={editMode}
              className="relative z-10 text-4xl md:text-6xl font-rustic text-white px-12 py-4 block tracking-widest uppercase"
            />
          </div>

          <InlineEdit
            value={data.posterConfig.titlePart2}
            onChange={(val) => updatePosterConfig('titlePart2', val)}
            isEditing={editMode}
            className="text-6xl md:text-8xl font-serif font-bold text-card-foreground block mt-4 tracking-widest uppercase drop-shadow-sm"
          />
        </div>

        {/* Decorative Divider */}
        <div className="flex justify-center items-center mb-12 relative z-30 space-x-4">
          <div className="h-1 w-24 bg-muted"></div>
          <div className="w-4 h-4 bg-secondary rotate-45"></div>
          <div className="w-6 h-6 bg-primary rotate-45"></div>
          <div className="w-4 h-4 bg-secondary rotate-45"></div>
          <div className="h-1 w-24 bg-muted"></div>
        </div>

        {/* Main Content Grid */}
        <div className="relative z-30 flex flex-col md:flex-row gap-8 md:gap-16 flex-1 mb-16">
          
          {/* Central Dotted Line */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0 border-l-4 border-dotted border-muted/50 -translate-x-1/2"></div>

          {/* Left Column */}
          <div className="flex-1 space-y-12">
            {/* TACOS */}
            <div className="bg-white/40 p-6 rounded-sm border-2 border-muted/30 shadow-sm">
              <div className="flex items-center justify-between mb-6 border-b-4 border-secondary pb-2">
                <h3 className="text-4xl font-rustic text-card-foreground tracking-widest">TACOS</h3>
                {editMode && (
                  <Button size="sm" variant="outline" className="bg-white border-muted text-card-foreground" onClick={() => addMenuItem('tacos', { name: 'NUEVO TACO', price: 0 })}>
                    <Plus className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <div className="space-y-2">
                {data.menu.tacos.map(item => renderMenuItem(item, 'tacos'))}
              </div>
            </div>

            {/* DESAYUNOS / ANTOJITOS */}
            <div className="bg-white/40 p-6 rounded-sm border-2 border-muted/30 shadow-sm">
              <div className="flex items-center justify-between mb-6 border-b-4 border-accent pb-2">
                <h3 className="text-3xl font-rustic text-card-foreground tracking-widest leading-tight">DESAYUNOS /<br/>ANTOJITOS</h3>
                {editMode && (
                  <Button size="sm" variant="outline" className="bg-white border-muted text-card-foreground" onClick={() => addMenuItem('desayunos', { name: 'NUEVO ANTOJITO', price: 0 })}>
                    <Plus className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <div className="space-y-2">
                {data.menu.desayunos.map(item => renderMenuItem(item, 'desayunos'))}
              </div>
            </div>
            
            {/* OTROS */}
            <div className="bg-white/40 p-6 rounded-sm border-2 border-muted/30 shadow-sm">
              <div className="flex items-center justify-between mb-6 border-b-4 border-secondary pb-2">
                <h3 className="text-4xl font-rustic text-card-foreground tracking-widest">OTROS</h3>
                {editMode && (
                  <Button size="sm" variant="outline" className="bg-white border-muted text-card-foreground" onClick={() => addMenuItem('otros', { name: 'NUEVO PLATILLO', price: 0 })}>
                    <Plus className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <div className="space-y-2">
                {data.menu.otros.map(item => renderMenuItem(item, 'otros'))}
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="flex-1 space-y-12">
            {/* QUESADILLAS / SINCRONIZADAS */}
            <div className="relative">
              <div className="absolute -inset-2 bg-secondary/10 transform rotate-1 z-0 rounded-sm border border-secondary/20"></div>
              <div className="relative z-10 bg-white/60 p-6 rounded-sm border-2 border-secondary shadow-sm">
                <div className="flex items-center justify-between mb-6 border-b-4 border-primary pb-2">
                  <h3 className="text-3xl font-rustic text-card-foreground tracking-widest leading-tight">QUESADILLAS /<br/>SINCRONIZADAS</h3>
                  {editMode && (
                    <Button size="sm" variant="outline" className="bg-white border-muted text-card-foreground" onClick={() => addMenuItem('quesadillas', { name: 'NUEVA QUESADILLA', price: 0 })}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  )}
                </div>
                <div className="space-y-2">
                  {data.menu.quesadillas.map(item => renderMenuItem(item, 'quesadillas'))}
                </div>
              </div>
            </div>

            {/* SÁBADOS Y DOMINGOS */}
            <div className="bg-white/40 p-6 rounded-sm border-2 border-muted/30 shadow-sm">
              <div className="flex items-center justify-between mb-6 border-b-4 border-accent pb-2">
                <h3 className="text-3xl font-rustic text-card-foreground tracking-widest leading-tight">SÁBADOS Y<br/>DOMINGOS</h3>
                {editMode && (
                  <Button size="sm" variant="outline" className="bg-white border-muted text-card-foreground" onClick={() => addMenuItem('weekendSpecials', { name: 'NUEVO ESPECIAL', price: 0 })}>
                    <Plus className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <div className="space-y-2">
                {data.menu.weekendSpecials.map(item => renderMenuItem(item, 'weekendSpecials'))}
              </div>
            </div>

            {/* BEBIDAS */}
            <div className="bg-white/40 p-6 rounded-sm border-2 border-muted/30 shadow-sm">
              <div className="flex items-center justify-between mb-6 border-b-4 border-secondary pb-2">
                <h3 className="text-4xl font-rustic text-card-foreground tracking-widest">BEBIDAS</h3>
                {editMode && (
                  <Button size="sm" variant="outline" className="bg-white border-muted text-card-foreground" onClick={() => addMenuItem('bebidas', { name: 'NUEVA BEBIDA', price: 0 })}>
                    <Plus className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <div className="space-y-2">
                {data.menu.bebidas.map(item => renderMenuItem(item, 'bebidas'))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer Text */}
        <div className="mt-auto relative z-30 w-full flex justify-center pb-4">
          <div className="bg-border py-6 px-8 md:px-16 text-center shadow-rustic rounded-sm relative w-[95%] max-w-3xl border-4 border-muted">
            {/* Decorative corners */}
            <div className="absolute top-2 left-2 w-4 h-4 border-t-4 border-l-4 border-secondary"></div>
            <div className="absolute top-2 right-2 w-4 h-4 border-t-4 border-r-4 border-secondary"></div>
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b-4 border-l-4 border-secondary"></div>
            <div className="absolute bottom-2 right-2 w-4 h-4 border-b-4 border-r-4 border-secondary"></div>

            <InlineEdit
              value={data.posterConfig.footerText}
              onChange={(val) => updatePosterConfig('footerText', val)}
              isEditing={editMode}
              className="text-3xl md:text-4xl lg:text-5xl font-serif font-bold text-white tracking-widest drop-shadow-md block uppercase"
            />
          </div>
        </div>
      </div>

      {/* Download Buttons */}
      <div className="mt-8 flex flex-col sm:flex-row gap-4 w-full max-w-md">
        <Button 
          onClick={handleDownloadPNG} 
          disabled={isDownloading}
          className="flex-1 bg-secondary hover:bg-secondary/90 text-white h-14 text-lg font-serif font-bold rounded-sm shadow-rustic border-4 border-border uppercase tracking-wider"
        >
          <Download className="w-5 h-5 mr-2" />
          Descargar PNG
        </Button>
        <Button 
          onClick={handleDownloadPDF} 
          disabled={isDownloading}
          className="flex-1 bg-primary hover:bg-primary/90 text-white h-14 text-lg font-serif font-bold rounded-sm shadow-rustic border-4 border-border uppercase tracking-wider"
        >
          <FileText className="w-5 h-5 mr-2" />
          Descargar PDF
        </Button>
      </div>
    </div>
  );
};

export default MenuPoster;
