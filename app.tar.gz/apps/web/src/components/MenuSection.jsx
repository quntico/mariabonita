
import React from 'react';
import MenuPoster from './MenuPoster.jsx';
import { motion } from 'framer-motion';

const MenuSection = () => {
  return (
    <section id="menu" className="py-24 bg-background relative overflow-hidden wood-pattern-dark border-y-[12px] border-border">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-30">
        <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-secondary blur-[100px]"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full bg-primary blur-[100px]"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16 bg-card/10 p-8 rounded-sm border-4 border-muted backdrop-blur-sm max-w-4xl mx-auto shadow-rustic"
        >
          <h2 className="text-5xl md:text-7xl font-serif font-bold text-foreground mb-6 uppercase tracking-wider drop-shadow-md">
            Nuestro Menú
          </h2>
          <div className="flex justify-center items-center space-x-4 mb-8">
            <div className="h-1 w-16 bg-secondary"></div>
            <div className="w-4 h-4 bg-primary rotate-45"></div>
            <div className="h-1 w-16 bg-secondary"></div>
          </div>
          <p className="text-foreground/90 max-w-2xl mx-auto font-serif text-2xl leading-relaxed font-medium">
            Descubre nuestros platillos tradicionales mexicanos preparados con amor, 
            recetas de la abuela y los mejores ingredientes.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <MenuPoster />
        </motion.div>
      </div>
    </section>
  );
};

export default MenuSection;
